package net.stars.UI;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
public class custRep extends JFrame{
    JPanel panels;
    JPanel panel;
    public custRep(JPanel panels){
        
    }
}
