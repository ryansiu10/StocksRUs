package net.stars.UI;

import javax.swing.JFrame;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class delTrans extends JFrame{
    JPanel panels;
    JPanel panel;
    public delTrans(JPanel panels){

    }
}
