package net.stars.UI;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class genMonth extends JFrame {
    JPanel panels;
    JPanel panel;

    JLabel set_int;
    JTextField rate;
    JButton add_int,back;

    public genMonth(JPanel panels,int tax_id){
        
    }
}