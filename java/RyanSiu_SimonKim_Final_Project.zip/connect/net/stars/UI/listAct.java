package net.stars.UI;

import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class listAct extends JFrame {
    JPanel panels;
    JPanel panel;
    public listAct(JPanel panels){
        
    }
}
