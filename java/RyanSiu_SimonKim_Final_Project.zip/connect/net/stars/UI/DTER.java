package net.stars.UI;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class DTER extends JFrame{
    JPanel panels;
    JPanel panel;
    public DTER(JPanel panels){
        
    }
}
